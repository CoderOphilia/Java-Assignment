package OphiliaAssignment2;

/**
 *<b>EmployeeSort class is used to prompt the users to enter employee information</b>
 *.matches() function is used here to check if the entered SIN number pattern matches with the expected pattern.
 * This class aims to gather required information of the employees and 
 * offer users the choice of displaying the objects in order by either ID or salary. 
 *
 *After collecting the information, it is stored inside the array which will be sorted and stored in the EmployeeDatabase
 */

import java.util.Scanner;

public class EmployeeSort {
	public static void main(String[] args) {
		//An array of Employee type which will save information of 5 employees
		 Employee[] employees = new Employee[5];
		 
		 Scanner scanner = new Scanner(System.in);
		 
		 /*
		  TASK D:
		   allows users to enter the information 
           of 5 employees and save the information in an array 
		  */
		 
		 //Using a loop to prompt the user to enter 5 employees information
		 for (int i = 0; i < employees.length; i++) {
			 System.out.println("Enter details for Employee " + (i + 1));
	         System.out.print("Employee ID: ");
	         String employeeID = scanner.nextLine();
	         
	       //1. Validating Social Security Number
			 String socialSecurityNumber;
			 while (true) {
	             System.out.print("Enter the Social Security Number (format: 999-99-9999): ");
	             socialSecurityNumber = scanner.nextLine();
	             if (socialSecurityNumber.matches("\\d{3}-\\d{2}-\\d{4}")) {
	                 break;
	             }
	             System.out.println("OOPS!! Invalid Social Security Number. Please try again.");
	         }
			 
			 //2. Getting the details of the employee
			 System.out.print("Enter the employee's First Name: ");
	         String firstName = scanner.nextLine();

	         System.out.print("Enter the employee's Last Name: ");
	         String lastName = scanner.nextLine();

	         System.out.print("Enter the employee's Address: ");
	         String address = scanner.nextLine();
	         
	         //3. Need to know which department the employee is
	         //Can use the enum Department for this. 
	         //The input gathered from the user has to be converted into upper case to match with the exact format of the enumeration values
		 
	         System.out.print("Enter the employee's Department (FINANCE, HR, IT, MARKETING): ");
	         Departments department = Departments.valueOf(scanner.nextLine().toUpperCase()); //valueOf(): Looks for a match in the enumeration
	         
	         System.out.print("Enter the employee's Annual Salary: ");
	         double annualSalary = scanner.nextDouble();
	         scanner.nextLine(); // This is to avoid the buffer
	         
	         employees[i] = new Employee(employeeID, socialSecurityNumber, new Person(firstName, lastName, address), department, annualSalary);
		 
		 }
		 
		 //Give user the choice the sort the data
		 System.out.println("Sort by:\n1. ID\n2. Salary");
	     int choice = scanner.nextInt();
		 
		 //After entering the choice, sort() method is used
	     
	     
	     //using Lambda expression which takes two employees information at a time to compare
	     //Instead of using Lambda expression, we can also use override and comparator method
	}
}
