package OphiliaAssignment2;

/**
 *<b>EmployeeSort class is used to prompt the users to enter employee information</b>
 *.matches() function is used here to check if the entered SIN number pattern matches with the expected pattern.
 */

import java.util.Scanner;

public class EmployeeSort {
	public static void main(String[] args) {
		//An array of Employee type which will save information of 5 employees
		 Employee[] employees = new Employee[5];
		 
		 Scanner scanner = new Scanner(System.in);
		 
		 /*
		  TASK D:
		   allows users to enter the information 
           of 5 employees and save the information in an array 
		  */
		 
		 //Using a loop to prompt the user to enter 5 employees information
		 for (int i = 0; i < employees.length; i++) {
			 System.out.println("Enter details for Employee " + (i + 1));
	         System.out.print("Employee ID: ");
	         String employeeID = scanner.nextLine();	 
		 }
		 
		 // Validating Social Security Number
		 String socialSecurityNumber;
		 while (true) {
             System.out.print("Enter the Social Security Number (format: 999-99-9999): ");
             socialSecurityNumber = scanner.nextLine();
             if (socialSecurityNumber.matches("\\d{3}-\\d{2}-\\d{4}")) {
                 break;
             }
             System.out.println("OOPS!! Invalid Social Security Number. Please try again.");
         }
	}
}
