package OphiliaAssignment2;

/**
  <b>This is a Person class and it contains 3 fields<b>
  Created Get methods for each field
 */

/*
 PART B:
 Create a class named Person that contains fields for a person’s first name, last name and 
 address. The class have  
• A constructor that accepts parameters for each field. 
• Get methods for each field.
 */

public class Person {
    //creating 3 fields
	private String firstName;
    private String lastName;
    private String address;
    
    //A constructor that accepts parameters for each feild
    public Person(String firstName, String lastName, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
    }
    
    //Get methods for each field
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAddress() {
        return address;
    }
}
