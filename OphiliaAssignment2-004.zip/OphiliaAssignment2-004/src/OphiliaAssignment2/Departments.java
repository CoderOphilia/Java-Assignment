package OphiliaAssignment2;

/* PART A:
Create an enumeration named Departments that contain four sets of values FINANCE, HR, 
IT and MARKETING. 
*/

public enum Departments {
	 FINANCE, HR, IT, MARKETING
}
