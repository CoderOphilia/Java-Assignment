package OphiliaAssignment2;

/**
 * <b>This is an employee class that contains fields for an employee ID, Social Security 
number, personal information (Person object), department (Departments type) and annual 
salary</b>

Created get and set method for each of the data fields. 
 */

public class Employee {
	
	//creating fields 
	private String employeeID;
    private String socialSecurityNumber;
    private Person personalInfo;
    private Departments department;
    private double annualSalary;
    
    //constructor 
    public Employee(String employeeID, String socialSecurityNumber, Person personalInfo, Departments department, double annualSalary) {
        this.employeeID = employeeID;
        this.socialSecurityNumber = socialSecurityNumber;
        this.personalInfo = personalInfo;
        this.department = department;
        this.annualSalary = annualSalary;
    }

    //getters and setters
	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}

	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}

	public Person getPersonalInfo() {
		return personalInfo;
	}

	public void setPersonalInfo(Person personalInfo) {
		this.personalInfo = personalInfo;
	}

	public Departments getDepartment() {
		return department;
	}

	public void setDepartment(Departments department) {
		this.department = department;
	}

	public double getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}
    
}
